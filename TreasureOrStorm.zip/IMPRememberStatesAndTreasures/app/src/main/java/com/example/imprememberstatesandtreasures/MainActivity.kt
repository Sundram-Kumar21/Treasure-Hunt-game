package com.example.imprememberstatesandtreasures

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.imprememberstatesandtreasures.ui.theme.IMPRememberStatesAndTreasuresTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IMPRememberStatesAndTreasuresTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    shit()
                }
            }
        }
    }
}

@Composable
fun shit() {
    val context = LocalContext.current
    val treasurefound = remember { mutableStateOf(0) }
    val direction = remember { mutableStateOf("North") }
    val stormortreasure = remember { mutableStateOf("")}

    Column(modifier = Modifier.fillMaxSize()) {
        Text( text = "Treasuers Found: ${treasurefound.value}")
        Spacer(modifier = Modifier.height(33.dp))
        Text(text = "Current Direction : ${direction.value}")
        //East
        Button(onClick = {
            direction.value = "East"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail East")
        }

        Text(text = stormortreasure.value)

        //West Direction
        Button(onClick = {
            direction.value = "West"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail West")
        }

        Text(text = stormortreasure.value)

        //South Direction
        Button(onClick = {
            direction.value = "South"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail South")
        }

        Text(text = stormortreasure.value)

        //North Direction
        Button(onClick = {
            direction.value = "North"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail North")
        }

        Text(text = stormortreasure.value)

        //North East Direction
        Button(onClick = {
            direction.value = "North East"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail North East")
        }

        Text(text = stormortreasure.value)

        //North West Direction
        Button(onClick = {
            direction.value = "North West"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            } else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail North West")
        }

        Text(text = stormortreasure.value)


        //South East direction
        Button(onClick = {
            direction.value = "South East"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail South East")
        }

        Text(text = stormortreasure.value)

        //South West direction
        Button(onClick = {
            direction.value = "South West"
            if(Random.nextBoolean()){
                treasurefound.value += 1
                Toast.makeText(context, "FOUND TREASURE!!", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(context, "STORM!!", Toast.LENGTH_SHORT).show()
            }
        }){
            Text(text = "Sail South West")
        }

        Text(text = stormortreasure.value)
    }
}

@Preview
@Composable
fun shitPreview(){
    shit()
}